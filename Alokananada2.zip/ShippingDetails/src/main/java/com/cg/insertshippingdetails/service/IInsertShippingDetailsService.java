package com.cg.insertshippingdetails.service;

import com.cg.insertshippingdetails.entities.OrderDetails;

public interface IInsertShippingDetailsService {
     public int insertShippingDetails(OrderDetails order);
}
