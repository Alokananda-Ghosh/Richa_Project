package com.cg.insertshippingdetails.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.insertshippingdetails.entities.OrderDetails;
import com.cg.insertshippingdetails.service.IInsertShippingDetailsService;

@RestController
public class ShippingDetailsController {

	@Autowired
	IInsertShippingDetailsService objService;

	public IInsertShippingDetailsService getObjService() {
		return objService;
	}

	public void setObjService(IInsertShippingDetailsService objService) {
		this.objService = objService;
	}
	
	@PostMapping("/insertShippingDetails")
	public int insertShippingDetails(@RequestBody OrderDetails order)
	{
		return objService.insertShippingDetails(order);
	}
	
}
