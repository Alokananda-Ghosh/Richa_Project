package com.cg.insertshippingdetails.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.insertshippingdetails.entities.OrderDetails;
import com.cg.insertshippingdetails.repo.IInsertShippingDetailsRepo;
@Service
@Transactional
public class ShippingDetailsServiceImpl implements IInsertShippingDetailsService{

	@Autowired
	IInsertShippingDetailsRepo objRepo;
	
	
	public IInsertShippingDetailsRepo getObjRepo() {
		return objRepo;
	}


	public void setObjRepo(IInsertShippingDetailsRepo objRepo) {
		this.objRepo = objRepo;
	}


	@Override
	public int insertShippingDetails(OrderDetails order) {
		// TODO Auto-generated method stub
		objRepo.save(order);
		return order.getOrderId();
	}

}
