package com.cg.insertshippingdetails.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class OrderedProduct {

	@Id
	private int orderedProductId;

	@OneToOne
	@JoinColumn(name = "productId")
	private Product productOrdered;
	private double productRating;
	private boolean isRatingProvided;

	@ManyToOne
	@JoinColumn(name = "orderId")
	private OrderDetails orderDetails;

	public int getOrderedProductId() {
		return orderedProductId;
	}

	public void setOrderedProductId(int orderedProductId) {
		this.orderedProductId = orderedProductId;
	}

	public double getProductRating() {
		return productRating;
	}

	public void setProductRating(double productRating) {
		this.productRating = productRating;
	}

	public boolean isRatingProvided() {
		return isRatingProvided;
	}

	public void setRatingProvided(boolean isRatingProvided) {
		this.isRatingProvided = isRatingProvided;
	}

	public Product getProductOrdered() {
		return productOrdered;
	}

	public void setProductOrdered(Product productOrdered) {
		this.productOrdered = productOrdered;
	}

	public OrderDetails getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(OrderDetails orderDetails) {
		this.orderDetails = orderDetails;
	}

	public OrderedProduct(int orderedProductId, Product productOrdered, double productRating, boolean isRatingProvided,
			OrderDetails orderDetails) {
		super();
		this.orderedProductId = orderedProductId;
		this.productOrdered = productOrdered;
		this.productRating = productRating;
		this.isRatingProvided = isRatingProvided;
		this.orderDetails = orderDetails;
	}

	public OrderedProduct() {
		// TODO Auto-generated constructor stub
	}
}
